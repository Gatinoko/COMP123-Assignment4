﻿Student: Gabriel Dias Tinoco
SID: 301160373

This program is a pseudo-music player.

1 - Upon running the program, the main window will appear. This window acts as the "central hub" for all music tracks. 
From this window, you can "play" music tracks using the "Play music" button (if you have any tracks added), and add new
music tracks to the program.
1.1 - In order to play a music track, simply select it from the dataGrid, and hit the "Play music" button.
1.2 - In order to add music tracks, click the "Add music" button.

2 - Clicking the "Add music" button will take you to the Add Music window, where you can add music tracks.
2.1 - In order to add a music track, you must first add an artist, throught the "Add new artist" tab.
2.2 - After adding a new artist, simply select it from the comboBox in the "Add new track" section and fill the information needed (for atrack to be added it must be 5 seconds or longer) 
in order to add a new music track.
2.3 - You can look up which music tracks belong to each artist by clicking the artist name on the dataGrid.
2.4 - To remove artists/music tracks, just select them on the datagrid, and click "Remove artist" or "Remove track"
